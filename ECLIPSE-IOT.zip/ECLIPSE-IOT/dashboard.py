import streamlit as st
import pandas as pd

from feature_engineering import extract_features
from anomaly_model import train_anomaly_model, detect_anomaly

st.title("ECLIPSE-IoT Security Dashboard")

data = pd.read_csv("dataset.csv")

st.subheader("Raw IoT Telemetry Data")
st.dataframe(data.head())

# Feature extraction
features = extract_features(data)

st.subheader("Extracted Behaviour Features")
st.dataframe(features.head())

# Keep only numeric features for ML model
numeric_features = features.select_dtypes(include=['number']).fillna(0)

# Train anomaly model
model, scaler = train_anomaly_model(numeric_features)

# Detect anomalies
predictions, scores = detect_anomaly(numeric_features, model, scaler)

features["anomaly"] = predictions

st.subheader("Traffic Behaviour Chart")

if "packet_rate" in features.columns:
    st.line_chart(features["packet_rate"])

# Show anomaly results
st.subheader("Anomaly Detection Results")

st.dataframe(features)

anomaly_count = (features["anomaly"] == -1).sum()

st.write("Number of suspicious behaviours detected:", anomaly_count)

# Show suspicious behaviours separately
st.subheader("Detected Suspicious IoT Behaviour")

anomalies = features[features["anomaly"] == -1]

if len(anomalies) > 0:
    st.dataframe(anomalies)
    st.error("⚠ Suspicious IoT behaviour detected!")
else:
    st.success("No suspicious behaviour detected")