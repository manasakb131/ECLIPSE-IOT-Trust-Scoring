def compute_trust(anomaly_score, drift_score, violations):

    trust = 100

    trust -= anomaly_score * 40

    trust -= drift_score * 30

    trust -= violations * 20

    trust = max(0,min(100,trust))

    return trust