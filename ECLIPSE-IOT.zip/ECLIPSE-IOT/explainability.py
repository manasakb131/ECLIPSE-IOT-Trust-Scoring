def explain(anomaly, drift, violation):

    reasons = []

    if anomaly:
        reasons.append("Traffic anomaly detected")

    if drift > 0.3:
        reasons.append("Behaviour deviates from baseline")

    if violation:
        reasons.append("Policy violation detected")

    return reasons