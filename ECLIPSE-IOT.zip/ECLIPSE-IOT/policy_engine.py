device_policies = {

"Camera":{
"allowed_ports":[80,443]
},

"TemperatureSensor":{
"allowed_ports":[1883]
},

"PLC":{
"allowed_ports":[502]
}

}

def check_policy(device_type,dst_port):

    violations = 0

    allowed = device_policies[device_type]["allowed_ports"]

    if dst_port not in allowed:
        violations += 1

    return violations