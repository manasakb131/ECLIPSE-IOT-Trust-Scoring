import pandas as pd

def extract_features(df):

    # Packet rate using Rate column
    if "Rate" in df.columns:
        df["packet_rate"] = df["Rate"]

    # Use Duration to normalize traffic
    if "Duration" in df.columns and "Rate" in df.columns:
        df["traffic_intensity"] = df["Rate"] / (df["Duration"] + 1)

    # Protocol feature
    if "Protocol Type" in df.columns:
        df["protocol_feature"] = df["Protocol Type"]

    # Header size feature
    if "Header_Length" in df.columns:
        df["header_size"] = df["Header_Length"]

    return df.fillna(0)