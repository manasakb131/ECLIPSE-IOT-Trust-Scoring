from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import IsolationForest

# Train anomaly detection model
def train_anomaly_model(data):

    scaler = StandardScaler()
    X = scaler.fit_transform(data)

    model = IsolationForest(contamination=0.1, random_state=42)
    model.fit(X)

    return model, scaler


# Detect anomalies
def detect_anomaly(data, model, scaler):

    X = scaler.transform(data)

    predictions = model.predict(X)   # -1 = anomaly, 1 = normal
    scores = model.decision_function(X)

    return predictions, scores