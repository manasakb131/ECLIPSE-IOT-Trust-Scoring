import numpy as np

def detect_drift(current, baseline):

    drift = np.abs(current - baseline)

    drift_score = np.mean(drift)

    return drift_score